import os,sys

#open a file
fd=os.open("g.jpg",os.O_RDWR|os.O_CREAT)

#get the info in var
info=os.fstat(fd)

print "FILE INFO IS AS FOLLOWS:"

print "FILE INODE NUMBER:",info.st_ino

print "DEVICE NUMBER:",info.st_dev

print "NUMBER OF LINK:",info.st_nlink

print "UID OF THE FILE:%d" % info.st_uid

print "GID OF THE FILE:%d" % info.st_gid

print "SIZE:",info.st_size

print "ACESS TIME:",info.st_atime

print "MODIFY TIME:",info.st_mtime

print "CHANGE TIME:",info.st_ctime

print "PROTECTION:",info.st_mode

print "NO OF BLOCKS ALLOCATED:",info.st_blocks

#close opened file

os.close(fd)


