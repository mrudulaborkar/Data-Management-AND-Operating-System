#include<iostream>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<string.h>
using namespace std;
int main()
{
        char str[20];
        
        cout<<"\nProgram Control reached in Process B Successfully..";
        int ch1=open("pipefile",O_RDONLY);              
        cout<<"\nReverse of string Received from process A --> ";
        read(ch1,&str,20);
        cout<< str;
        cout<<"\n"
        close(ch1);
        unlink("pipefile");
                
        return 0;
}

