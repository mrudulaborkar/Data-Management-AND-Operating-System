#include<iostream>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<string.h>
using namespace std;
int main()
{
    char str[20], rev[20];
    int ch1, count=0, i;
        int ch=mkfifo("pipefile",0666);
        if(ch==-1)
                cout<<"mkfifo error : Cannot make Pipe file...";
        else
        {
                cout<<"Pipe File Created Successfully..";
                cout<<"Enter A String to Reverse --> ";
                cin>>str;
                ch1=open("pipefile",O_WRONLY);
        i=0;
        while(str[i]!='\0')
        {
        i++;
        count++;
        }
        count--;
        for(int j=0;j<i;j++)
        {
        rev[j]=str[count];
        count--;
        }
        write(ch1,rev,strlen(rev));
                
        }
        close(ch1);
        return 0;
}
