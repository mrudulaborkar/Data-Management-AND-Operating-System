#!use/bin/env python

import socket

TCP_IP='127.0.0.1'
TCP_PORT=6041
BUFFER_SIZE=2000


s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect((TCP_IP,TCP_PORT))

name=raw_input("ENTER FILE NAME: ")
f=open(name,'r+')
a=f.read()
print "DATA SENT: ",a

s.send(a)
data=s.recv(BUFFER_SIZE)

s.close()

